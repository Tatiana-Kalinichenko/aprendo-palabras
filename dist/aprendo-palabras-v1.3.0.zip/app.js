const STORAGE_KEY = "aprendo-espanol-cards-v1";
    const STUDY_SIDE_MODE_KEY = "aprendo-espanol-study-side-mode";
    const MAX_LEARNING = 30;
    const MAX_REINFORCEMENT = 100;
    const PAGE_SIZE_KEY = "aprendo-espanol-page-size";
    const PAGE_SIZE_OPTIONS = [50, 100, 200, 500];
    const DEFAULT_PAGE_SIZE = 50;

    const MODE_LABELS = {
      dictionary: "Словник",
      learning: "Вивчення",
      reinforcement: "Закріплення",
      known: "Знаю"
    };

    const MODE_ORDER = ["dictionary", "learning", "reinforcement", "known"];

    const STUDY_SESSION_LABELS = {
      learning: "Вивчення",
      reinforcement: "Закріплення",
      review: "Повтор"
    };

    const STUDY_SESSION_CARD_MODES = {
      learning: "learning",
      reinforcement: "reinforcement",
      review: "known"
    };

    let state = { cards: [], tags: [] };
    let selectedIds = new Set();
    let study = null;
    let studyHistory = [];
    let studyDeck = createEmptyStudyDeck();
    let studyPipWindow = null;
    let studyPipOpening = false;
    let studyPipNoticeTimer = null;
    let toastTimer = null;

    let currentPage = 1;
    let pageSize = DEFAULT_PAGE_SIZE;
    let savedStudySideMode = null;
    let storageBackend = "local";
    let storageWriteQueue = Promise.resolve();
    let storageSyncBound = false;

    const $ = (selector) => document.querySelector(selector);

    const els = {
      stats: $("#stats"),
      studyBtn: $("#studyBtn"),
      closeStudyBtn: $("#closeStudyBtn"),
      studySessionMode: $("#studySessionMode"),
      studySideMode: $("#studySideMode"),
      exportCsvBtn: $("#exportCsvBtn"),
      importCsvBtn: $("#importCsvBtn"),
      csvFileInput: $("#csvFileInput"),
      studyPanel: $("#studyPanel"),
      createCardForm: $("#createCardForm"),
      cardFront: $("#cardFront"),
      cardBack: $("#cardBack"),
      cardFrontSuggestions: $("#cardFrontSuggestions"),
      cardBackSuggestions: $("#cardBackSuggestions"),
      cardNotes: $("#cardNotes"),
      createTagPicker: $("#createTagPicker"),
      newTagsInput: $("#newTagsInput"),
      quickTagName: $("#quickTagName"),
      quickAddTag: $("#quickAddTag"),
      tagList: $("#tagList"),
      searchInput: $("#searchInput"),
      modeFilter: $("#modeFilter"),
      sortSelect: $("#sortSelect"),
      pageRangeInfo: $("#pageRangeInfo"),
      pageSizeSelect: $("#pageSizeSelect"),
      prevPageBtn: $("#prevPageBtn"),
      nextPageBtn: $("#nextPageBtn"),
      selectedInfo: $("#selectedInfo"),
      clearSelectionBtn: $("#clearSelectionBtn"),
      bulkModeSelect: $("#bulkModeSelect"),
      bulkTagInput: $("#bulkTagInput"),
      bulkApplyMode: $("#bulkApplyMode"),
      bulkAddTags: $("#bulkAddTags"),
      bulkReplaceTags: $("#bulkReplaceTags"),
      bulkRemoveTags: $("#bulkRemoveTags"),
      bulkDelete: $("#bulkDelete"),
      tableWrap: $("#tableWrap"),
      modalBackdrop: $("#cardModalBackdrop"),
      closeCardModal: $("#closeCardModal"),
      editCardForm: $("#editCardForm"),
      editCardId: $("#editCardId"),
      editFront: $("#editFront"),
      editBack: $("#editBack"),
      editNotes: $("#editNotes"),
      editMode: $("#editMode"),
      editTagPicker: $("#editTagPicker"),
      editNewTagsInput: $("#editNewTagsInput"),
      deleteFromModal: $("#deleteFromModal"),
      toast: $("#toast")
    };

    function getDefaultState() {
      return { cards: [], tags: [] };
    }

    function normalizeStoredState(value) {
      try {
        const parsed = typeof value === "string" ? JSON.parse(value) : value;
        if (!parsed || typeof parsed !== "object") return getDefaultState();

        return {
          cards: Array.isArray(parsed.cards) ? parsed.cards : [],
          tags: Array.isArray(parsed.tags) ? parsed.tags : []
        };
      } catch (error) {
        console.warn("Could not parse stored data", error);
        return getDefaultState();
      }
    }

    function normalizePageSize(value) {
      const saved = Number(value);
      return PAGE_SIZE_OPTIONS.includes(saved) ? saved : DEFAULT_PAGE_SIZE;
    }

    function normalizeStudySideMode(value) {
      return ["front", "back", "random"].includes(value) ? value : null;
    }

    function canUseExtensionStorage() {
      return typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
    }

    function chromeStorageGet(keys) {
      return new Promise((resolve, reject) => {
        chrome.storage.local.get(keys, (items) => {
          const error = chrome.runtime && chrome.runtime.lastError;
          if (error) {
            reject(new Error(error.message));
            return;
          }

          resolve(items || {});
        });
      });
    }

    function chromeStorageSet(items) {
      return new Promise((resolve, reject) => {
        chrome.storage.local.set(items, () => {
          const error = chrome.runtime && chrome.runtime.lastError;
          if (error) {
            reject(new Error(error.message));
            return;
          }

          resolve();
        });
      });
    }

    function readLocalStorageValue(key) {
      try {
        return localStorage.getItem(key);
      } catch (error) {
        console.warn(`Could not read ${key} from localStorage`, error);
        return null;
      }
    }

    function writeLocalStorageValue(key, value) {
      try {
        localStorage.setItem(key, value);
      } catch (error) {
        console.warn(`Could not write ${key} to localStorage`, error);
      }
    }

    function hasOwn(object, key) {
      return Object.prototype.hasOwnProperty.call(object, key);
    }

    function cloneStorageValue(value) {
      return value && typeof value === "object" ? JSON.parse(JSON.stringify(value)) : value;
    }

    async function loadStoredData() {
      if (!canUseExtensionStorage()) {
        state = normalizeStoredState(readLocalStorageValue(STORAGE_KEY));
        pageSize = normalizePageSize(readLocalStorageValue(PAGE_SIZE_KEY));
        savedStudySideMode = normalizeStudySideMode(readLocalStorageValue(STUDY_SIDE_MODE_KEY));
        return;
      }

      try {
        storageBackend = "extension";

        const stored = await chromeStorageGet([STORAGE_KEY, PAGE_SIZE_KEY, STUDY_SIDE_MODE_KEY]);
        const migrated = {};

        if (hasOwn(stored, STORAGE_KEY)) {
          state = normalizeStoredState(stored[STORAGE_KEY]);
        } else {
          state = normalizeStoredState(readLocalStorageValue(STORAGE_KEY));
          migrated[STORAGE_KEY] = state;
        }

        if (hasOwn(stored, PAGE_SIZE_KEY)) {
          pageSize = normalizePageSize(stored[PAGE_SIZE_KEY]);
        } else {
          pageSize = normalizePageSize(readLocalStorageValue(PAGE_SIZE_KEY));
          migrated[PAGE_SIZE_KEY] = pageSize;
        }

        if (hasOwn(stored, STUDY_SIDE_MODE_KEY)) {
          savedStudySideMode = normalizeStudySideMode(stored[STUDY_SIDE_MODE_KEY]);
        } else {
          savedStudySideMode = normalizeStudySideMode(readLocalStorageValue(STUDY_SIDE_MODE_KEY));
          if (savedStudySideMode) {
            migrated[STUDY_SIDE_MODE_KEY] = savedStudySideMode;
          }
        }

        if (Object.keys(migrated).length) {
          await chromeStorageSet(migrated);
        }
      } catch (error) {
        console.warn("Could not load extension storage, falling back to localStorage", error);
        storageBackend = "local";
        state = normalizeStoredState(readLocalStorageValue(STORAGE_KEY));
        pageSize = normalizePageSize(readLocalStorageValue(PAGE_SIZE_KEY));
        savedStudySideMode = normalizeStudySideMode(readLocalStorageValue(STUDY_SIDE_MODE_KEY));
      }
    }

    function saveStoredValue(key, value) {
      if (storageBackend === "extension") {
        const snapshot = cloneStorageValue(value);

        storageWriteQueue = storageWriteQueue
          .catch(() => {})
          .then(() => chromeStorageSet({ [key]: snapshot }))
          .catch((error) => {
            console.warn(`Could not save ${key} to extension storage`, error);
          });

        return storageWriteQueue;
      }

      writeLocalStorageValue(key, typeof value === "string" ? value : JSON.stringify(value));
      return Promise.resolve();
    }

    function saveState() {
      return saveStoredValue(STORAGE_KEY, {
        cards: state.cards,
        tags: state.tags
      });
    }

    function bindExternalStorageSync() {
      if (storageSyncBound || storageBackend !== "extension" || !chrome.storage?.onChanged) return;

      storageSyncBound = true;
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local" || !changes[STORAGE_KEY]) return;

        state = normalizeStoredState(changes[STORAGE_KEY].newValue);
        sortTags();
        renderAll();
      });
    }

    function uid(prefix) {
      if (window.crypto && crypto.randomUUID) {
        return crypto.randomUUID();
      }
      return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    }

    function normalize(value) {
      return String(value || "").trim().toLocaleLowerCase("uk");
    }

    function escapeHtml(value) {
      return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
    }

    function normalizeSideSuggestionText(value) {
      return String(value || "")
        .trim()
        .replace(/\s+/g, " ")
        .toLocaleLowerCase("uk");
    }

    function getSideSuggestionMatches(side, value) {
      const query = normalizeSideSuggestionText(value);
      if (!query) return [];

      return state.cards.filter((card) => {
        const sideText = side === "front" ? card.front : card.back;
        return normalizeSideSuggestionText(sideText).startsWith(query);
      });
    }

    function renderSideSuggestionList(container, matches) {
      if (!container) return;

      if (!matches.length) {
        container.hidden = true;
        container.innerHTML = "";
        return;
      }

      container.hidden = false;
      container.innerHTML = matches.map((card) => `
        <div class="side-suggestion">${escapeHtml(card.front)} &mdash; ${escapeHtml(card.back)}</div>
      `).join("");
    }

    function renderCreateSideSuggestions() {
      renderSideSuggestionList(
        els.cardFrontSuggestions,
        getSideSuggestionMatches("front", els.cardFront.value)
      );
      renderSideSuggestionList(
        els.cardBackSuggestions,
        getSideSuggestionMatches("back", els.cardBack.value)
      );
    }

    function multiline(value) {
      return escapeHtml(value).replace(/\n/g, "<br>");
    }

    function splitTags(value) {
      return String(value || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
    }

    function uniqueByNormalized(names) {
      const seen = new Set();
      return names.filter((name) => {
        const key = normalize(name);
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      });
    }

    function ensureTags(names) {
      const ids = [];
      for (const name of uniqueByNormalized(names)) {
        const existing = state.tags.find((tag) => normalize(tag.name) === normalize(name));
        if (existing) {
          ids.push(existing.id);
        } else {
          const tag = { id: uid("tag"), name: name.trim() };
          state.tags.push(tag);
          ids.push(tag.id);
        }
      }
      sortTags();
      return ids;
    }

    function sortTags() {
      state.tags.sort((a, b) => a.name.localeCompare(b.name, "uk", { sensitivity: "base" }));
    }

    function getTagNames(card) {
      return (card.tagIds || [])
        .map((id) => state.tags.find((tag) => tag.id === id))
        .filter(Boolean)
        .map((tag) => tag.name)
        .sort((a, b) => a.localeCompare(b, "uk", { sensitivity: "base" }));
    }

    function getPrimaryTagName(card) {
      return getTagNames(card)[0] || "Без тегів";
    }

    function isExistingCardId(id) {
      return state.cards.some((card) => card.id === id);
    }

    function getSelectedCardIds() {
      const checkedIds = Array.from(els.tableWrap.querySelectorAll(".card-check:checked"))
        .map((checkbox) => checkbox.dataset.cardId)
        .filter(Boolean);

      for (const id of checkedIds) {
        selectedIds.add(id);
      }

      selectedIds = new Set(Array.from(selectedIds).filter(isExistingCardId));
      return Array.from(selectedIds);
    }

    function updateSelectedInfo() {
      selectedIds = new Set(Array.from(selectedIds).filter(isExistingCardId));

      const selectedCount = selectedIds.size;
      els.selectedInfo.textContent = `Обрано: ${selectedCount}`;

      if (els.clearSelectionBtn) {
        els.clearSelectionBtn.disabled = selectedCount === 0;
      }
    }

    function sortHeaderButton(sortValue, label, activeSort) {
      const isActive = activeSort === sortValue;
      return `<button class="sort-header ${isActive ? "active" : ""}" data-sort="${escapeHtml(sortValue)}" type="button">${escapeHtml(label)}${isActive ? '<span class="sort-indicator">↑</span>' : ''}</button>`;
    }

    function getInitialStudySide() {
  const mode = els.studySideMode ? els.studySideMode.value : "random";

  if (mode === "front") return "front";
  if (mode === "back") return "back";

  return Math.random() < 0.5 ? "front" : "back";
}

function createEmptyStudyDeck(sessionMode = null) {
  return {
    sessionMode,
    queueIds: [],
    lastCycleIds: []
  };
}

function resetStudyDeck(sessionMode = null) {
  studyDeck = createEmptyStudyDeck(sessionMode);
}

function getStudyCardMode(sessionMode) {
  return STUDY_SESSION_CARD_MODES[sessionMode] || STUDY_SESSION_CARD_MODES.learning;
}

function getStudySessionLabel(sessionMode) {
  return STUDY_SESSION_LABELS[sessionMode] || STUDY_SESSION_LABELS.learning;
}

function shuffleIds(ids) {
  const shuffled = ids.slice();

  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[randomIndex]] = [shuffled[randomIndex], shuffled[index]];
  }

  return shuffled;
}

function isSameOrder(first, second) {
  return first.length === second.length && first.every((id, index) => id === second[index]);
}

function rotateFirstIdToEnd(ids) {
  return ids.length > 1 ? ids.slice(1).concat(ids[0]) : ids;
}

function avoidSameCycleOrder(ids, previousIds) {
  if (ids.length <= 1 || !isSameOrder(ids, previousIds)) return ids;

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const shuffled = shuffleIds(ids);
    if (!isSameOrder(shuffled, previousIds)) return shuffled;
  }

  return rotateFirstIdToEnd(ids);
}

function avoidImmediateRepeat(ids, previousId, previousCycleIds = []) {
  if (ids.length <= 1 || !previousId || ids[0] !== previousId) return ids;

  const rotated = rotateFirstIdToEnd(ids);
  return isSameOrder(rotated, previousCycleIds) ? ids : rotated;
}

function buildStudyCycle(ids, previousCycleIds, previousId) {
  const shuffled = avoidSameCycleOrder(shuffleIds(ids), previousCycleIds);
  return avoidImmediateRepeat(shuffled, previousId, previousCycleIds);
}

function setStudyCard(card, options = {}) {
  const {
  rememberCurrent = true,
  scroll = true,
  sessionMode = study?.sessionMode || getSelectedStudySessionMode()
} = options;

  if (rememberCurrent && study?.cardId && study.cardId !== card.id) {
    studyHistory.push(study.cardId);
  }

  study = {
  sessionMode,
  cardId: card.id,
  side: getInitialStudySide(),
  flipped: false,
  answer: ""
};

  renderAll();

  if (scroll) {
    els.studyPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

    function getModeLimit(mode) {
  if (mode === "learning") return MAX_LEARNING;
  if (mode === "reinforcement") return MAX_REINFORCEMENT;
  return Infinity;
}

function getModeLimitMessage(mode) {
  if (mode === "learning") {
    return `У режимі “Вивчення” може бути не більше ${MAX_LEARNING} карток.`;
  }

  if (mode === "reinforcement") {
    return `У режимі “Закріплення” може бути не більше ${MAX_REINFORCEMENT} карток.`;
  }

  return "";
}

function canMoveToMode(ids, mode) {
  const limit = getModeLimit(mode);
  if (!Number.isFinite(limit)) return true;

  const idSet = new Set(Array.from(ids).filter(isExistingCardId));
  const currentOutsideSelection = state.cards.filter((card) => card.mode === mode && !idSet.has(card.id)).length;
  const movingIntoMode = state.cards.filter((card) => idSet.has(card.id) && card.mode !== mode).length;

  return currentOutsideSelection + movingIntoMode <= limit;
}

function getModeRank(mode) {
  const rank = MODE_ORDER.indexOf(mode);
  return rank >= 0 ? rank : MODE_ORDER.indexOf("dictionary");
}

function getHigherMode(firstMode, secondMode) {
  return getModeRank(firstMode) >= getModeRank(secondMode) ? firstMode : secondMode;
}

function getImportModeFallbacks(mode) {
  const modeIndex = getModeRank(mode);
  return MODE_ORDER.slice(0, modeIndex + 1).reverse();
}

function canFitImportedMode(mode, ignoredCardId = null) {
  const limit = getModeLimit(mode);
  if (!Number.isFinite(limit)) return true;

  const count = state.cards.filter((card) => card.mode === mode && card.id !== ignoredCardId).length;
  return count < limit;
}

function resolveImportMode(mode, existingCard = null) {
  const currentMode = existingCard?.mode || null;
  const currentRank = currentMode ? getModeRank(currentMode) : getModeRank("dictionary");

  for (const candidate of getImportModeFallbacks(mode)) {
    if (getModeRank(candidate) < currentRank) break;
    if (candidate === currentMode || canFitImportedMode(candidate, existingCard?.id || null)) {
      return candidate;
    }
  }

  return currentMode || "dictionary";
}

function getSelectedStudySessionMode() {
  const selectedMode = els.studySessionMode?.value;
  return STUDY_SESSION_CARD_MODES[selectedMode] ? selectedMode : "learning";
}

    function showToast(message) {
      window.clearTimeout(toastTimer);
      els.toast.textContent = message;
      els.toast.classList.add("show");
      showStudyPictureInPictureToast(message);
      toastTimer = window.setTimeout(() => {
        els.toast.classList.remove("show");
      }, 2600);
    }

    function renderAll() {
      selectedIds = new Set(Array.from(selectedIds).filter((id) => state.cards.some((card) => card.id === id)));
      renderStats();
      renderTagPickers();
      renderTagList();
      renderCardList();
      renderCreateSideSuggestions();
      renderStudy();
      updateStudyButton();
    }

    function renderStats() {
  const counts = {
    dictionary: state.cards.filter((card) => card.mode === "dictionary").length,
    learning: state.cards.filter((card) => card.mode === "learning").length,
    reinforcement: state.cards.filter((card) => card.mode === "reinforcement").length,
    known: state.cards.filter((card) => card.mode === "known").length
  };

  els.stats.innerHTML = `
    <span class="stat"><strong>${state.cards.length}</strong> карток усього</span>
    <span class="stat"><strong>${counts.dictionary}</strong> у Словнику</span>
    <span class="stat"><strong>${counts.learning}/${MAX_LEARNING}</strong> у Вивченні</span>
    <span class="stat"><strong>${counts.reinforcement}/${MAX_REINFORCEMENT}</strong> у Закріпленні</span>
    <span class="stat"><strong>${counts.known}</strong> Знаю</span>
    <span class="stat"><strong>${state.tags.length}</strong> тегів</span>
`;
}

    function renderTagPickers() {
      const renderPicker = (container, name, selected = []) => {
        if (!state.tags.length) {
          container.innerHTML = `<p class="muted-text">Тегів ще немає. Створіть нові через поле нижче.</p>`;
          return;
        }

        container.innerHTML = state.tags.map((tag) => `
          <label class="tag-check">
            <input type="checkbox" name="${name}" value="${escapeHtml(tag.id)}" ${selected.includes(tag.id) ? "checked" : ""}>
            ${escapeHtml(tag.name)}
          </label>
        `).join("");
      };

      renderPicker(els.createTagPicker, "createTags");
      const editCard = state.cards.find((card) => card.id === els.editCardId.value);
      renderPicker(els.editTagPicker, "editTags", editCard ? editCard.tagIds || [] : []);
    }

    function renderTagList() {
      if (!state.tags.length) {
        els.tagList.innerHTML = `<div class="empty">Теги ще не створені.</div>`;
        return;
      }

      els.tagList.innerHTML = state.tags.map((tag) => {
        const count = state.cards.filter((card) => (card.tagIds || []).includes(tag.id)).length;
        return `
          <div class="tag-line">
            <div>
              <strong>${escapeHtml(tag.name)}</strong>
              <div class="muted-text">${count} карт.</div>
            </div>
            <div class="row-actions">
              <button class="mini icon-btn" data-tag-action="rename" data-tag-id="${escapeHtml(tag.id)}" aria-label="Редагувати тег" title="Редагувати тег">✎</button>
              <button class="mini danger icon-btn" data-tag-action="delete" data-tag-id="${escapeHtml(tag.id)}" aria-label="Видалити тег" title="Видалити тег">🗑</button>
            </div>
          </div>
        `;
      }).join("");
    }

    function getVisibleCards() {
      const search = normalize(els.searchInput.value);
      const mode = els.modeFilter.value;
      const sort = els.sortSelect.value;

      const filtered = state.cards.filter((card) => {
        const tagNames = getTagNames(card).join(" ");
        const haystack = normalize(`${card.front} ${card.back} ${card.notes || ""} ${tagNames}`);
        const matchesSearch = !search || haystack.includes(search);
        const matchesMode = mode === "all" || card.mode === mode;
        return matchesSearch && matchesMode;
      });

      filtered.sort((a, b) => {
        if (sort === "back") {
          return a.back.localeCompare(b.back, "uk", { sensitivity: "base" });
        }
        if (sort === "tags") {
          return getPrimaryTagName(a).localeCompare(getPrimaryTagName(b), "uk", { sensitivity: "base" })
            || a.front.localeCompare(b.front, "uk", { sensitivity: "base" });
        }
        if (sort === "mode") {
          return MODE_ORDER.indexOf(a.mode) - MODE_ORDER.indexOf(b.mode)
            || a.front.localeCompare(b.front, "uk", { sensitivity: "base" });
        }
        return a.front.localeCompare(b.front, "uk", { sensitivity: "base" });
      });

      return filtered;
    }

    function getPageCount(total) {
      return Math.max(1, Math.ceil(total / pageSize));
    }

    function clampCurrentPage(total) {
      const pageCount = getPageCount(total);
      currentPage = Math.min(Math.max(currentPage, 1), pageCount);
      return pageCount;
    }

    function getPaginatedCards(cards) {
      const pageCount = clampCurrentPage(cards.length);
      const startIndex = (currentPage - 1) * pageSize;
      const endIndex = Math.min(startIndex + pageSize, cards.length);

      return {
        cards: cards.slice(startIndex, endIndex),
        startIndex,
        endIndex,
        pageCount
      };
    }

    function getDisplayedCards() {
      return getPaginatedCards(getVisibleCards()).cards;
    }

    function updatePaginationControls(totalFiltered, startIndex, endIndex, pageCount) {
      if (els.pageSizeSelect && els.pageSizeSelect.value !== String(pageSize)) {
      els.pageSizeSelect.value = String(pageSize);
      }

      els.pageRangeInfo.textContent = totalFiltered
      ? `${startIndex + 1}-${endIndex} з ${totalFiltered}`
        : "0-0 з 0";

      els.prevPageBtn.disabled = currentPage <= 1 || totalFiltered === 0;
      els.nextPageBtn.disabled = currentPage >= pageCount || totalFiltered === 0;
    }

    function resetPageAndRenderCardList() {
      currentPage = 1;
      renderCardList();
    }

    function clearAllSelections() {
      if (!selectedIds.size) {
        showToast("Немає обраних карток.");
        return;
      }

      selectedIds.clear();
      renderCardList();
      showToast("Усі виділення знято.");
    }

    function renderCardList() {
      const visible = getVisibleCards();
      const {
        cards: pageCards,
        startIndex,
        endIndex,
        pageCount
      } = getPaginatedCards(visible);

      const allVisibleSelected = pageCards.length > 0 && pageCards.every((card) => selectedIds.has(card.id));

      updateSelectedInfo();
      updatePaginationControls(visible.length, startIndex, endIndex, pageCount);

      if (!state.cards.length) {
        els.tableWrap.innerHTML = `<div class="empty">Поки що немає жодної картки. Створіть першу зліва.</div>`;
        return;
      }

      if (!visible.length) {
        els.tableWrap.innerHTML = `<div class="empty">За поточним пошуком нічого не знайдено.</div>`;
        return;
      }

      const sort = els.sortSelect.value;
      let lastGroup = null;
      const rows = [];

      for (const card of pageCards) {
        const group = sort === "tags" ? getPrimaryTagName(card) : sort === "mode" ? MODE_LABELS[card.mode] : null;
        if (group && group !== lastGroup) {
          rows.push(`<tr class="group-row"><td colspan="8">${escapeHtml(group)}</td></tr>`);
          lastGroup = group;
        }

        const tagsHtml = getTagNames(card).map((name) => `<span class="tag">${escapeHtml(name)}</span>`).join("") || `<span class="muted-text">Без тегів</span>`;
        const notes = card.notes ? `<div class="muted-text">${multiline(card.notes)}</div>` : `<span class="muted-text">—</span>`;

        rows.push(`
          <tr>
            <td>
              <input type="checkbox" class="card-check" data-card-id="${escapeHtml(card.id)}" ${selectedIds.has(card.id) ? "checked" : ""}>
            </td>
            <td class="word-cell">${multiline(card.front)}</td>
            <td class="word-cell">${multiline(card.back)}</td>
            <td>${notes}</td>
            <td>${tagsHtml}</td>
            <td><span class="mode-badge mode-${escapeHtml(card.mode)}">${MODE_LABELS[card.mode]}</span></td>
            <td>
              <select data-card-action="mode" data-card-id="${escapeHtml(card.id)}" aria-label="Змінити режим картки">
                <option value="dictionary" ${card.mode === "dictionary" ? "selected" : ""}>Словник</option>
                <option value="learning" ${card.mode === "learning" ? "selected" : ""}>Вивчення</option>
                <option value="reinforcement" ${card.mode === "reinforcement" ? "selected" : ""}>Закріплення</option>
                <option value="known" ${card.mode === "known" ? "selected" : ""}>Знаю</option>
              </select>
            </td>
            <td>
              <div class="row-actions">
                <button class="mini icon-btn" data-card-action="edit" data-card-id="${escapeHtml(card.id)}" aria-label="Редагувати картку" title="Редагувати картку">✎</button>
                <button class="mini danger icon-btn" data-card-action="delete" data-card-id="${escapeHtml(card.id)}" aria-label="Видалити картку" title="Видалити картку">🗑</button>
              </div>
            </td>
          </tr>
        `);
      }

      els.tableWrap.innerHTML = `
        <table>
          <colgroup>
            <col class="select-col">
            <col class="word-col">
            <col class="word-col">
            <col class="notes-col">
            <col class="tags-col">
            <col class="mode-col">
            <col class="change-col">
            <col class="actions-col">
          </colgroup>
          <thead>
            <tr>
              <th><input type="checkbox" id="selectAllVisible" ${allVisibleSelected ? "checked" : ""} aria-label="Обрати всі видимі картки"></th>
              <th>${sortHeaderButton("front", "Сторона 1", sort)}</th>
              <th>${sortHeaderButton("back", "Сторона 2", sort)}</th>
              <th>Примітки</th>
              <th>${sortHeaderButton("tags", "Теги", sort)}</th>
              <th>${sortHeaderButton("mode", "Режим", sort)}</th>
              <th>Змінити</th>
              <th>Дії</th>
            </tr>
          </thead>
          <tbody>${rows.join("")}</tbody>
        </table>
      `;
    }

    function updateStudyButton() {
     const sessionMode = getSelectedStudySessionMode();
      const cardMode = getStudyCardMode(sessionMode);
      const cardsCount = state.cards.filter((card) => card.mode === cardMode).length;
      const sessionLabel = getStudySessionLabel(sessionMode);

      els.studyBtn.disabled = cardsCount < 1;
     els.studyBtn.textContent = cardsCount < 1 ? `Немає карток: ${sessionLabel}` : "Вчити";
     els.closeStudyBtn.style.display = study ? "block" : "none";
    }

function canUseDocumentPictureInPicture() {
  return Boolean(window.documentPictureInPicture?.requestWindow);
}

function getStudyPictureInPictureWindow() {
  const apiWindow = window.documentPictureInPicture?.window || null;
  const pipWindow = apiWindow || studyPipWindow;

  if (pipWindow && !pipWindow.closed) {
    studyPipWindow = pipWindow;
    return pipWindow;
  }

  studyPipWindow = null;
  return null;
}

function getStudyAnswerElement(sourceDocument = document) {
  return sourceDocument.querySelector("[data-study-answer]") || sourceDocument.querySelector("#studyAnswer");
}

function syncStudyAnswerFromDocument(sourceDocument = document) {
  if (!study) return;

  const answerEl = getStudyAnswerElement(sourceDocument);
  if (answerEl) study.answer = answerEl.value;
}

function syncStudyAnswerToMain() {
  if (!study) return;

  const answerEl = getStudyAnswerElement(document);
  if (answerEl && answerEl.value !== study.answer) {
    answerEl.value = study.answer;
  }
}

function syncStudyAnswerToPictureInPicture() {
  if (!study) return;

  const pipWindow = getStudyPictureInPictureWindow();
  const answerEl = pipWindow ? getStudyAnswerElement(pipWindow.document) : null;
  if (answerEl && answerEl.value !== study.answer) {
    answerEl.value = study.answer;
  }
}

function getStudyDisplayData() {
  if (!study) return null;

  const sessionMode = STUDY_SESSION_CARD_MODES[study.sessionMode] ? study.sessionMode : "learning";
  const cardMode = getStudyCardMode(sessionMode);
  const card = state.cards.find((item) => item.id === study.cardId);

  if (!card || card.mode !== cardMode) return null;

  const side = study.side === "back" ? "back" : "front";
  const showingSide = study.flipped
    ? (side === "front" ? "back" : "front")
    : side;

  return {
    sessionMode,
    cardMode,
    card,
    showingSide,
    label: showingSide === "front"
      ? "Сторона 1 — українською"
      : "Сторона 2 — іспанською",
    text: showingSide === "front" ? card.front : card.back,
    notesHtml: showingSide === "back" && card.notes
      ? `<div class="study-notes">${multiline(card.notes)}</div>`
      : ""
  };
}

function getStudyModeControls(sessionMode) {
  return sessionMode === "reinforcement"
    ? `
      <button class="mini blue" data-study-action="dictionary" type="button">&lt;- Словник</button>
      <button class="mini" data-study-action="learning" type="button">&lt;- Вчити</button>
      <button class="mini good" data-study-action="known" type="button">Знаю -&gt;</button>
    `
    : `
      <button class="mini blue" data-study-action="dictionary" type="button">&lt;- Словник</button>
      <button class="mini good" data-study-action="reinforcement" type="button">Закріпити -&gt;</button>
    `;
}

function getStudyPipButtonHtml() {
  const unsupportedTitle = "Міні-вікно доступне тільки в Google Chrome desktop з Document Picture-in-Picture.";

  if (!canUseDocumentPictureInPicture()) {
    return `<button class="mini study-pip-button" data-study-pip-button type="button" disabled title="${unsupportedTitle}">Міні-вікно</button>`;
  }

  const isOpen = Boolean(getStudyPictureInPictureWindow());
  const label = studyPipOpening ? "Відкриваємо..." : isOpen ? "Міні-вікно відкрите" : "Міні-вікно";
  const title = isOpen ? "Міні-вікно вже відкрите" : "Відкрити поточну картку в міні-вікні";
  const disabled = studyPipOpening ? " disabled" : "";

  return `<button class="mini study-pip-button" data-study-action="open-pip" data-study-pip-button type="button" title="${title}"${disabled}>${label}</button>`;
}

function updateStudyPictureInPictureButton() {
  const button = els.studyPanel.querySelector("[data-study-pip-button]");
  if (!button) return;

  if (!canUseDocumentPictureInPicture()) {
    button.disabled = true;
    button.title = "Міні-вікно доступне тільки в Google Chrome desktop з Document Picture-in-Picture.";
    button.textContent = "Міні-вікно";
    return;
  }

  const isOpen = Boolean(getStudyPictureInPictureWindow());
  button.disabled = studyPipOpening;
  button.textContent = studyPipOpening ? "Відкриваємо..." : isOpen ? "Міні-вікно відкрите" : "Міні-вікно";
  button.title = isOpen ? "Міні-вікно вже відкрите" : "Відкрити поточну картку в міні-вікні";
}

function getStudyPictureInPictureStyles() {
  return `
    :root {
      color-scheme: light;
      --bg: #fff8f0;
      --panel: #ffffff;
      --ink: #27211f;
      --muted: #7a6e68;
      --line: #ead8c9;
      --soft: #f8efe6;
      --accent: #d55f3f;
      --accent-dark: #a9402a;
      --green: #2e7d59;
      --green-soft: #dff4e9;
      --blue: #3b65a7;
      --blue-soft: #e3ebfb;
      --danger: #b73232;
      --danger-soft: #ffe2e2;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      min-width: 300px;
      min-height: 100vh;
      background: var(--bg);
      color: var(--ink);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }

    button,
    textarea {
      font: inherit;
    }

    button {
      cursor: pointer;
    }

    button:disabled {
      cursor: not-allowed;
      opacity: 0.52;
    }

    .study-pip-root {
      display: grid;
      gap: 12px;
      padding: 14px;
    }

    .study-pip-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }

    .study-pip-title {
      font-weight: 850;
      color: var(--accent-dark);
    }

    .study-pip-window-actions,
    .study-icon-row,
    .study-mode-row {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-wrap: wrap;
      gap: 8px;
    }

    .study-pip-card {
      min-height: 180px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      border: 1px solid var(--line);
      border-radius: 18px;
      background: var(--panel);
      padding: 22px 18px;
      text-align: center;
      box-shadow: inset 0 0 0 6px rgba(255, 248, 240, 0.88);
    }

    .side-label {
      margin: 0 0 10px;
      color: var(--muted);
      font-size: 0.72rem;
      font-weight: 900;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }

    .study-pip-word {
      margin: 0;
      font-size: 2.5rem;
      line-height: 1.05;
      overflow-wrap: anywhere;
      white-space: pre-wrap;
    }

    .study-notes {
      margin: 14px 0 0;
      color: var(--muted);
      font-size: 0.9rem;
      line-height: 1.4;
      white-space: pre-wrap;
    }

    .study-pip-answer-label {
      color: var(--muted);
      font-size: 0.78rem;
      font-weight: 800;
    }

    .study-pip-answer {
      width: 100%;
      min-height: 76px;
      resize: vertical;
      border: 1px solid var(--line);
      border-radius: 14px;
      background: #fff;
      color: var(--ink);
      padding: 10px 12px;
    }

    .mini,
    .primary,
    .ghost {
      border: 0;
      border-radius: 999px;
      font-weight: 800;
    }

    .mini {
      padding: 7px 11px;
      background: var(--soft);
      color: var(--ink);
      border: 1px solid var(--line);
      font-size: 0.82rem;
    }

    .mini.good {
      background: var(--green-soft);
      color: var(--green);
    }

    .mini.blue {
      background: var(--blue-soft);
      color: var(--blue);
    }

    .mini.danger {
      background: var(--danger-soft);
      color: var(--danger);
    }

    .primary,
    .ghost {
      width: 42px;
      height: 42px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0;
      font-size: 1.2rem;
      line-height: 1;
    }

    .primary {
      background: var(--accent);
      color: #fff;
    }

    .ghost {
      background: var(--soft);
      color: var(--ink);
      border: 1px solid var(--line);
    }

    .study-pip-toast {
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 12px;
      padding: 10px 12px;
      border-radius: 999px;
      background: var(--ink);
      color: #fff;
      text-align: center;
      font-weight: 780;
      opacity: 0;
      transform: translateY(18px);
      transition: opacity 0.18s ease, transform 0.18s ease;
      pointer-events: none;
    }

    .study-pip-toast.show {
      opacity: 1;
      transform: translateY(0);
    }

    @media (max-width: 340px) {
      .study-pip-word {
        font-size: 2rem;
      }
    }
  `;
}

function setupStudyPictureInPictureWindow(pipWindow) {
  const pipDocument = pipWindow.document;
  pipDocument.documentElement.lang = "uk";
  pipDocument.title = "Aprendo Palabras - міні-вікно";
  pipDocument.head.innerHTML = "";
  pipDocument.body.innerHTML = "";
  pipDocument.body.className = "study-pip-body";

  const meta = pipDocument.createElement("meta");
  meta.name = "viewport";
  meta.content = "width=device-width, initial-scale=1";
  pipDocument.head.append(meta);

  const style = pipDocument.createElement("style");
  style.textContent = getStudyPictureInPictureStyles();
  pipDocument.head.append(style);

  const root = pipDocument.createElement("main");
  root.className = "study-pip-root";
  root.setAttribute("data-study-pip-root", "");
  pipDocument.body.append(root);

  const toast = pipDocument.createElement("div");
  toast.className = "study-pip-toast";
  toast.setAttribute("data-pip-toast", "");
  pipDocument.body.append(toast);

  pipDocument.addEventListener("click", (event) => {
    const pipButton = event.target.closest("[data-pip-action]");
    if (pipButton?.dataset.pipAction === "return") {
      returnToStudyTabFromPictureInPicture();
      return;
    }

    if (pipButton?.dataset.pipAction === "close") {
      closeStudyPictureInPicture();
      return;
    }

    const studyButton = event.target.closest("[data-study-action]");
    if (studyButton) {
      handleStudyAction(studyButton.dataset.studyAction, {
        sourceDocument: pipDocument,
        scroll: false
      });
    }
  });

  pipDocument.addEventListener("input", (event) => {
    if (event.target.matches("[data-study-answer]") && study) {
      study.answer = event.target.value;
      syncStudyAnswerToMain();
    }
  });
}

function showStudyPictureInPictureToast(message) {
  const pipWindow = getStudyPictureInPictureWindow();
  const toast = pipWindow?.document.querySelector("[data-pip-toast]");
  if (!toast) return;

  window.clearTimeout(studyPipNoticeTimer);
  toast.textContent = message;
  toast.classList.add("show");
  studyPipNoticeTimer = window.setTimeout(() => {
    if (!pipWindow.closed) {
      toast.classList.remove("show");
    }
  }, 2600);
}

function renderStudyPictureInPicture() {
  const pipWindow = getStudyPictureInPictureWindow();
  if (!pipWindow) return;

  const data = getStudyDisplayData();
  if (!data) {
    closeStudyPictureInPicture();
    return;
  }

  const pipDocument = pipWindow.document;
  const root = pipDocument.querySelector("[data-study-pip-root]");
  if (!root) {
    setupStudyPictureInPictureWindow(pipWindow);
    renderStudyPictureInPicture();
    return;
  }

  root.innerHTML = `
    <header class="study-pip-header">
      <div class="study-pip-title">Aprendo Palabras</div>
      <div class="study-pip-window-actions">
        <button class="mini" data-pip-action="return" type="button" title="Повернутись до режиму вивчення у вкладці">У вкладку</button>
        <button class="mini danger" data-pip-action="close" type="button" title="Закрити міні-вікно">Закрити</button>
      </div>
    </header>

    <section class="study-pip-card">
      <p class="side-label">${escapeHtml(data.label)}</p>
      <p class="study-pip-word">${multiline(data.text)}</p>
      ${data.notesHtml}
    </section>

    <label class="study-pip-answer-label" for="studyPipAnswer">Ваш переклад</label>
    <textarea id="studyPipAnswer" class="study-pip-answer" data-study-answer placeholder="Поле необовʼязкове">${escapeHtml(study.answer)}</textarea>

    <div class="study-icon-row">
      <button class="ghost" data-study-action="previous" type="button" aria-label="Попередня картка" title="Попередня картка">←</button>
      <button class="primary" data-study-action="flip" type="button" aria-label="Перевернути" title="Перевернути">↻</button>
      <button class="ghost" data-study-action="next" type="button" aria-label="Наступна картка" title="Наступна картка">→</button>
    </div>

    <div class="study-mode-row">
      ${getStudyModeControls(data.sessionMode)}
    </div>
  `;

  updateStudyPictureInPictureButton();
}

async function openStudyPictureInPicture() {
  if (!study) return;

  if (!canUseDocumentPictureInPicture()) {
    showToast("Міні-вікно доступне тільки в Google Chrome desktop.");
    return;
  }

  const existingWindow = getStudyPictureInPictureWindow();
  if (existingWindow) {
    renderStudyPictureInPicture();
    try {
      existingWindow.focus();
    } catch (error) {
      console.warn("Could not focus Picture-in-Picture window", error);
    }
    return;
  }

  if (studyPipOpening) return;

  studyPipOpening = true;
  updateStudyPictureInPictureButton();

  try {
    const pipWindow = await window.documentPictureInPicture.requestWindow({
      width: 380,
      height: 560,
      disallowReturnToOpener: true
    });

    studyPipWindow = pipWindow;
    setupStudyPictureInPictureWindow(pipWindow);
    renderStudyPictureInPicture();

    pipWindow.addEventListener("pagehide", () => {
      if (studyPipWindow === pipWindow) {
        studyPipWindow = null;
      }
      studyPipOpening = false;
      window.clearTimeout(studyPipNoticeTimer);
      updateStudyPictureInPictureButton();
    }, { once: true });
  } catch (error) {
    console.warn("Could not open Document Picture-in-Picture window", error);
    showToast("Не вдалося відкрити міні-вікно. Спробуйте ще раз після кліку.");
  } finally {
    studyPipOpening = false;
    updateStudyPictureInPictureButton();
  }
}

function closeStudyPictureInPicture() {
  const pipWindow = getStudyPictureInPictureWindow();
  if (!pipWindow) {
    updateStudyPictureInPictureButton();
    return;
  }

  try {
    pipWindow.close();
  } catch (error) {
    console.warn("Could not close Picture-in-Picture window", error);
  }
}

function returnToStudyTabFromPictureInPicture() {
  if (study) {
    els.studyPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  try {
    window.focus();
  } catch (error) {
    console.warn("Could not focus opener window", error);
  }

  closeStudyPictureInPicture();
}

function renderStudy() {
  if (!study) {
    els.studyPanel.classList.remove("active");
    els.studyPanel.innerHTML = "";
    closeStudyPictureInPicture();
    return;
  }

  const sessionMode = STUDY_SESSION_CARD_MODES[study.sessionMode] ? study.sessionMode : "learning";
  const data = getStudyDisplayData();

  if (!data) {
    pickStudyCard(study.cardId, { rememberCurrent: false, sessionMode });
    return;
  }

  els.studyPanel.classList.add("active");

  const controls = `
    <div class="study-pip-row">
      ${getStudyPipButtonHtml()}
    </div>

    <label for="studyAnswer">Ваш переклад, якщо хочете перевірити себе</label>

    <textarea id="studyAnswer" class="answer-box" data-study-answer placeholder="Поле необовʼязкове. Напишіть переклад і натисніть кнопку перевороту.">${escapeHtml(study.answer)}</textarea>

    <div class="study-icon-row">
      <button class="ghost icon-btn study-nav-icon" data-study-action="previous" type="button" aria-label="Попередня картка" title="Попередня картка">←</button>

      <button class="primary icon-btn study-nav-icon" data-study-action="flip" type="button" aria-label="Перевернути" title="Перевернути">↻</button>

      <button class="ghost icon-btn study-nav-icon" data-study-action="next" type="button" aria-label="Наступна картка" title="Наступна картка">→</button>

      <button class="mini icon-btn study-nav-icon" data-study-action="edit" type="button" aria-label="Редагувати картку" title="Редагувати картку">✎</button>
    </div>

    <div class="study-mode-row">
      ${getStudyModeControls(data.sessionMode)}
    </div>
  `;

  els.studyPanel.innerHTML = `
    <div class="study-layout">
      <div class="flashcard">
        <p class="side-label">${escapeHtml(data.label)}</p>
        <p class="card-word">${multiline(data.text)}</p>
        ${data.notesHtml}
      </div>

      <div class="study-controls">
        <div>
          <h2 class="study-title">Режим: ${escapeHtml(getStudySessionLabel(data.sessionMode))}</h2>
          <p class="hint study-hint">Категорії тут не показуються, щоб не підказувати відповідь.</p>
        </div>

        ${controls}
      </div>
    </div>
  `;

  renderStudyPictureInPicture();
}

    function getCheckedTagIds(container) {
      return Array.from(container.querySelectorAll("input[type='checkbox']:checked")).map((input) => input.value);
    }

    function createCard(event) {
      event.preventDefault();

      const front = els.cardFront.value.trim();
      const back = els.cardBack.value.trim();
      if (!front || !back) {
        showToast("Заповніть обидві сторони картки.");
        return;
      }

      const tagIds = [
        ...getCheckedTagIds(els.createTagPicker),
        ...ensureTags(splitTags(els.newTagsInput.value))
      ];

      state.cards.push({
        id: uid("card"),
        front,
        back,
        notes: els.cardNotes.value.trim(),
        tagIds: Array.from(new Set(tagIds)),
        mode: "dictionary",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });

      saveState();
      els.createCardForm.reset();
      renderAll();
      showToast("Картку створено в режимі “Словник”.");
    }

    function openCardModal(cardId) {
      const card = state.cards.find((item) => item.id === cardId);
      if (!card) return;

      els.editCardId.value = card.id;
      els.editFront.value = card.front;
      els.editBack.value = card.back;
      els.editNotes.value = card.notes || "";
      els.editMode.value = card.mode;
      els.editNewTagsInput.value = "";
      renderTagPickers();
      els.modalBackdrop.classList.add("active");
      els.editFront.focus();
    }

    function closeCardModal() {
      els.modalBackdrop.classList.remove("active");
      els.editCardForm.reset();
      els.editCardId.value = "";
    }

    function saveCardEdit(event) {
      event.preventDefault();

      const card = state.cards.find((item) => item.id === els.editCardId.value);
      if (!card) return;

      const newMode = els.editMode.value;
      if (newMode !== card.mode && !canMoveToMode([card.id], newMode)) {
        showToast(getModeLimitMessage(newMode));
        els.editMode.value = card.mode;
        return;
      }

      const tagIds = [
        ...getCheckedTagIds(els.editTagPicker),
        ...ensureTags(splitTags(els.editNewTagsInput.value))
      ];

      card.front = els.editFront.value.trim();
      card.back = els.editBack.value.trim();
      card.notes = els.editNotes.value.trim();
      card.mode = newMode;
      card.tagIds = Array.from(new Set(tagIds));
      card.updatedAt = new Date().toISOString();

      if (!card.front || !card.back) {
        showToast("Обидві сторони картки мають бути заповнені.");
        return;
      }

      saveState();
      closeCardModal();
      renderAll();
      showToast("Картку оновлено.");
    }

    function deleteCards(ids) {
      const idList = Array.from(ids);
      if (!idList.length) {
        showToast("Спочатку оберіть картки.");
        return;
      }

      const confirmed = confirm(`Видалити картки: ${idList.length}? Цю дію неможливо скасувати.`);
      if (!confirmed) return;

      state.cards = state.cards.filter((card) => !idList.includes(card.id));
      selectedIds = new Set(Array.from(selectedIds).filter((id) => !idList.includes(id)));

      if (study && idList.includes(study.cardId)) {
        study = null;
        studyHistory = [];
        resetStudyDeck();
      }

      saveState();
      renderAll();
      showToast("Картки видалено.");
    }

    function moveCards(ids, mode) {
      if (!MODE_LABELS[mode]) {
        showToast("Оберіть коректний режим.");
        return false;
      }

      const idList = Array.from(new Set(Array.from(ids).filter(isExistingCardId)));
      if (!idList.length) {
        showToast("Спочатку оберіть картки.");
        return false;
      }

      if (!canMoveToMode(idList, mode)) {
        showToast(getModeLimitMessage(mode));
        return false;
      }

      let changedCount = 0;
      for (const card of state.cards) {
        if (idList.includes(card.id) && card.mode !== mode) {
          card.mode = mode;
          card.updatedAt = new Date().toISOString();
          changedCount += 1;
        }
      }

      if (study) {
        const current = state.cards.find((card) => card.id === study.cardId);
        const sessionMode = study.sessionMode || getSelectedStudySessionMode();
        const cardMode = getStudyCardMode(sessionMode);

        if (!current || current.mode !== cardMode) {
          pickStudyCard(study.cardId, { rememberCurrent: false, sessionMode });
        }
      }

      saveState();
      renderAll();
      const message = changedCount
        ? `Режим змінено: ${MODE_LABELS[mode]} (${changedCount}).`
        : `Обрані картки вже були в режимі “${MODE_LABELS[mode]}”.`;
      showToast(message);
      return true;
    }

    function applyTagChange(ids, action) {
      const idList = Array.from(ids);
      if (!idList.length) {
        showToast("Спочатку оберіть картки.");
        return;
      }

      const names = splitTags(els.bulkTagInput.value);
      if (!names.length) {
        showToast("Введіть один або кілька тегів через кому.");
        return;
      }

      const tagIds = ensureTags(names);

      for (const card of state.cards) {
        if (!idList.includes(card.id)) continue;

        if (action === "replace") {
          card.tagIds = Array.from(new Set(tagIds));
        } else if (action === "add") {
          card.tagIds = Array.from(new Set([...(card.tagIds || []), ...tagIds]));
        } else if (action === "remove") {
          card.tagIds = (card.tagIds || []).filter((id) => !tagIds.includes(id));
        }

        card.updatedAt = new Date().toISOString();
      }

      els.bulkTagInput.value = "";
      saveState();
      renderAll();
      showToast("Теги оновлено.");
    }

    function renameTag(tagId) {
      const tag = state.tags.find((item) => item.id === tagId);
      if (!tag) return;

      const name = prompt("Нова назва тегу:", tag.name);
      if (name === null) return;

      const trimmed = name.trim();
      if (!trimmed) {
        showToast("Назва тегу не може бути порожньою.");
        return;
      }

      const duplicate = state.tags.find((item) => item.id !== tagId && normalize(item.name) === normalize(trimmed));
      if (duplicate) {
        const confirmed = confirm("Такий тег уже існує. Обʼєднати ці теги?");
        if (!confirmed) return;

        for (const card of state.cards) {
          if ((card.tagIds || []).includes(tagId)) {
            card.tagIds = Array.from(new Set((card.tagIds || []).map((id) => id === tagId ? duplicate.id : id)));
          }
        }
        state.tags = state.tags.filter((item) => item.id !== tagId);
      } else {
        tag.name = trimmed;
      }

      sortTags();
      saveState();
      renderAll();
      showToast("Тег оновлено на всіх картках.");
    }

    function deleteTag(tagId) {
      const tag = state.tags.find((item) => item.id === tagId);
      if (!tag) return;

      const confirmed = confirm(`Видалити тег “${tag.name}”? Картки залишаться, але без цього тегу.`);
      if (!confirmed) return;

      state.tags = state.tags.filter((item) => item.id !== tagId);
      for (const card of state.cards) {
        card.tagIds = (card.tagIds || []).filter((id) => id !== tagId);
      }

      saveState();
      renderAll();
      showToast("Тег видалено з усіх карток.");
    }

    function addQuickTag() {
      const name = els.quickTagName.value.trim();
      if (!name) {
        showToast("Введіть назву тегу.");
        return;
      }

      const existing = state.tags.find((tag) => normalize(tag.name) === normalize(name));
      if (existing) {
        showToast("Такий тег уже існує.");
        return;
      }

      state.tags.push({ id: uid("tag"), name });
      sortTags();
      els.quickTagName.value = "";
      saveState();
      renderAll();
      showToast("Тег створено.");
    }

    function csvEscape(value) {
      const text = String(value ?? "");
      if (/[",\n\r]/.test(text)) {
        return `"${text.replaceAll('"', '""')}"`;
      }
      return text;
    }

    function exportCardsToCsv() {
      const headers = ["side_1_ukrainian", "side_2_spanish", "notes", "mode", "tags"];
      const rows = state.cards.map((card) => [
        card.front,
        card.back,
        card.notes || "",
        card.mode || "dictionary",
        getTagNames(card).join("; ")
      ]);

      const csv = [headers, ...rows]
        .map((row) => row.map(csvEscape).join(","))
        .join("\r\n");

      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const date = new Date().toISOString().slice(0, 10);
      link.href = url;
      link.download = `aprendo-espanol-cards-${date}.csv`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      showToast(state.cards.length ? "CSV експортовано." : "Експортовано порожній CSV-шаблон.");
    }

    function parseCsv(text) {
      const rows = [];
      let row = [];
      let field = "";
      let inQuotes = false;

      const cleanText = String(text || "").replace(/^\uFEFF/, "");

      for (let i = 0; i < cleanText.length; i += 1) {
        const char = cleanText[i];
        const next = cleanText[i + 1];

        if (char === '"') {
          if (inQuotes && next === '"') {
            field += '"';
            i += 1;
          } else {
            inQuotes = !inQuotes;
          }
          continue;
        }

        if (char === "," && !inQuotes) {
          row.push(field);
          field = "";
          continue;
        }

        if ((char === "\n" || char === "\r") && !inQuotes) {
          if (char === "\r" && next === "\n") i += 1;
          row.push(field);
          if (row.some((item) => item.trim() !== "")) rows.push(row);
          row = [];
          field = "";
          continue;
        }

        field += char;
      }

      row.push(field);
      if (row.some((item) => item.trim() !== "")) rows.push(row);
      return rows;
    }

    function countMatches(text, pattern) {
      const matches = String(text || "").match(pattern);
      return matches ? matches.length : 0;
    }

    function scoreDecodedCsvText(text) {
      const value = String(text || "");
      const rows = parseCsv(value).slice(0, 12);
      const replacementCount = countMatches(value, /�/g);
      const suspiciousMojibakeCount = countMatches(value, /(?:Ð|Ñ|Ã|Â|Р|С)/g);
      const controlCount = countMatches(value, /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g);
      const cyrillicCount = countMatches(value, /[А-Яа-яЄєІіЇїҐґ]/g);
      const spanishAccentCount = countMatches(value, /[áéíóúüñÁÉÍÓÚÜÑ¿¡]/g);
      const headerScore = looksLikeCsvHeader(rows[0] || []) ? 200 : 0;
      const tableScore = rows.reduce((sum, row) => {
        const filled = row.filter((cell) => String(cell || "").trim()).length;
        return sum + Math.min(filled, 5) * 8;
      }, 0);

      return headerScore + tableScore + cyrillicCount * 3 + spanishAccentCount * 3
        - replacementCount * 250 - suspiciousMojibakeCount * 14 - controlCount * 80;
    }

    function decodeCsvArrayBuffer(buffer) {
      const bytes = new Uint8Array(buffer);
      const hasUtf8Bom = bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF;
      const hasUtf16LeBom = bytes[0] === 0xFF && bytes[1] === 0xFE;
      const hasUtf16BeBom = bytes[0] === 0xFE && bytes[1] === 0xFF;

      const decodeWith = (label, fatal = false) => new TextDecoder(label, { fatal }).decode(buffer);

      if (hasUtf8Bom) return { text: decodeWith("utf-8"), encoding: "UTF-8 BOM" };
      if (hasUtf16LeBom) return { text: decodeWith("utf-16le"), encoding: "UTF-16 LE" };
      if (hasUtf16BeBom) return { text: decodeWith("utf-16be"), encoding: "UTF-16 BE" };

      const evenNulls = bytes.filter((byte, index) => index % 2 === 0 && byte === 0).length;
      const oddNulls = bytes.filter((byte, index) => index % 2 === 1 && byte === 0).length;
      if (oddNulls > bytes.length * 0.2 && evenNulls < oddNulls / 3) {
        return { text: decodeWith("utf-16le"), encoding: "UTF-16 LE" };
      }
      if (evenNulls > bytes.length * 0.2 && oddNulls < evenNulls / 3) {
        return { text: decodeWith("utf-16be"), encoding: "UTF-16 BE" };
      }

      try {
        return { text: decodeWith("utf-8", true), encoding: "UTF-8" };
      } catch (error) {
        // Not valid UTF-8, so the file was likely saved by Excel/Windows in another encoding.
      }

      const candidates = ["windows-1251", "windows-1252", "iso-8859-1"]
        .map((label) => ({ label, text: decodeWith(label) }))
        .map((candidate) => ({
          ...candidate,
          score: scoreDecodedCsvText(candidate.text)
        }))
        .sort((a, b) => b.score - a.score);

      const best = candidates[0];
      const encodingNames = {
        "windows-1251": "Windows-1251",
        "windows-1252": "Windows-1252",
        "iso-8859-1": "ISO-8859-1"
      };

      return { text: best.text, encoding: encodingNames[best.label] || best.label };
    }

    function normalizeHeader(value) {
      return normalize(value).replace(/[\s_-]+/g, "");
    }

    function mapCsvMode(value) {
      const key = normalize(value);

      if (["learning", "вивчення", "учу", "вчу"].includes(key)) return "learning";

      if (["reinforcement", "закріплення", "закріпити", "повторення", "review"].includes(key)) {
        return "reinforcement";
      }

      if (["known", "знаю", "вивчено"].includes(key)) return "known";

      return "dictionary";
    }

    function splitCsvTags(value) {
      return String(value || "")
        .split(/[;|]/)
        .map((item) => item.trim())
        .filter(Boolean);
    }

    function normalizeCsvCardSide(value) {
      return String(value || "").trim();
    }

    function findImportedCardDuplicate(front, back) {
      return state.cards.find((card) => (
        normalizeCsvCardSide(card.front) === front
        && normalizeCsvCardSide(card.back) === back
      ));
    }

    function appendUniqueNotes(card, notes) {
      const importedNotes = String(notes || "").trim();
      if (!importedNotes) return false;

      const currentNotes = String(card.notes || "").trim();
      if (currentNotes.includes(importedNotes)) return false;

      card.notes = currentNotes ? `${currentNotes}\n${importedNotes}` : importedNotes;
      return true;
    }

    function mergeCardTagIds(card, tagIds) {
      const currentTagIds = Array.isArray(card.tagIds) ? card.tagIds : [];
      const mergedTagIds = Array.from(new Set([...currentTagIds, ...tagIds]));
      const changed = mergedTagIds.length !== currentTagIds.length
        || mergedTagIds.some((id, index) => id !== currentTagIds[index]);

      if (changed) {
        card.tagIds = mergedTagIds;
      }

      return changed;
    }

    function mergeImportedCardMetadata(card, importedCard) {
      let changed = false;

      if (appendUniqueNotes(card, importedCard.notes)) {
        changed = true;
      }

      if (mergeCardTagIds(card, importedCard.tagIds)) {
        changed = true;
      }

      const currentMode = card.mode || "dictionary";
      const desiredMode = getHigherMode(currentMode, importedCard.mode || "dictionary");
      const resolvedMode = resolveImportMode(desiredMode, card);
      const modeLimited = getModeRank(resolvedMode) < getModeRank(desiredMode);

      if (resolvedMode !== card.mode) {
        card.mode = resolvedMode;
        changed = true;
      }

      if (changed) {
        card.updatedAt = new Date().toISOString();
      }

      return { changed, modeLimited };
    }

    function getCsvColumnIndexes(headerRow) {
      const normalized = headerRow.map(normalizeHeader);
      const findAny = (names, fallback) => {
        const keys = names.map(normalizeHeader);
        const index = normalized.findIndex((name) => keys.includes(name));
        return index >= 0 ? index : fallback;
      };

      return {
        front: findAny(["side_1_ukrainian", "side 1", "сторона 1", "українською", "front"], 0),
        back: findAny(["side_2_spanish", "side 2", "сторона 2", "іспанською", "spanish", "back"], 1),
        notes: findAny(["notes", "примітки", "синоніми", "відмінювання"], 2),
        mode: findAny(["mode", "режим"], 3),
        tags: findAny(["tags", "теги", "категорії", "categories"], 4)
      };
    }

    function looksLikeCsvHeader(row) {
      const names = row.map(normalizeHeader);
      return names.some((name) => [
        "side1ukrainian", "side2spanish", "сторона1", "сторона2",
        "українською", "іспанською", "front", "back", "notes", "mode", "tags"
      ].includes(name));
    }

    function importCardsFromCsvText(text, sourceEncoding = "") {
      const rows = parseCsv(text);
      if (!rows.length) {
        showToast("CSV-файл порожній.");
        return;
      }

      const hasHeader = looksLikeCsvHeader(rows[0]);
      const indexes = hasHeader ? getCsvColumnIndexes(rows[0]) : { front: 0, back: 1, notes: 2, mode: 3, tags: 4 };
      const dataRows = hasHeader ? rows.slice(1) : rows;
      let imported = 0;
      let skipped = 0;
      let updatedDuplicates = 0;
      let unchangedDuplicates = 0;
      let limitedModeFallbacks = 0;

      for (const row of dataRows) {
        const front = normalizeCsvCardSide(row[indexes.front]);
        const back = normalizeCsvCardSide(row[indexes.back]);

        if (!front || !back) {
          skipped += 1;
          continue;
        }

        const requestedMode = mapCsvMode(row[indexes.mode] || "dictionary");
        const notes = String(row[indexes.notes] || "").trim();
        const tagIds = ensureTags(splitCsvTags(row[indexes.tags] || ""));
        const duplicate = findImportedCardDuplicate(front, back);

        if (duplicate) {
          const result = mergeImportedCardMetadata(duplicate, { notes, tagIds, mode: requestedMode });
          if (result.modeLimited) limitedModeFallbacks += 1;
          if (result.changed) updatedDuplicates += 1;
          else unchangedDuplicates += 1;
          continue;
        }

        const mode = resolveImportMode(requestedMode);
        if (getModeRank(mode) < getModeRank(requestedMode)) {
          limitedModeFallbacks += 1;
        }

        state.cards.push({
          id: uid("card"),
          front,
          back,
          notes,
          tagIds,
          mode,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        imported += 1;
      }

      if (!imported && !updatedDuplicates && !unchangedDuplicates) {
        showToast("Не імпортовано жодної картки. Перевірте, чи заповнені перші дві колонки.");
        return;
      }

      if (imported || updatedDuplicates) {
        selectedIds.clear();
        saveState();
        renderAll();
      }

      let message = imported ? `Імпортовано нових карток: ${imported}.` : "Нових карток не імпортовано.";
      if (updatedDuplicates) message += ` Оновлено дублікатів: ${updatedDuplicates}.`;
      if (unchangedDuplicates) message += ` Дублікатів без змін: ${unchangedDuplicates}.`;
      if (sourceEncoding) message += ` Кодування: ${sourceEncoding}.`;
      if (skipped) message += ` Пропущено рядків: ${skipped}.`;
      if (limitedModeFallbacks) {
        message += ` ${limitedModeFallbacks} карт. розміщено в нижчий доступний режим через ліміт.`;
      }
      showToast(message);
    }

    function importCardsFromCsvFile(file) {
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        try {
          const decoded = decodeCsvArrayBuffer(reader.result);
          importCardsFromCsvText(decoded.text, decoded.encoding);
        } catch (error) {
          showToast("Не вдалося розпізнати кодування CSV-файлу. Спробуйте зберегти файл як CSV UTF-8.");
        }
      };
      reader.onerror = () => showToast("Не вдалося прочитати CSV-файл.");
      reader.readAsArrayBuffer(file);
    }

    function pickStudyCard(excludeId = null, options = {}) {
      const sessionMode = options.sessionMode || study?.sessionMode || getSelectedStudySessionMode();
      const cardMode = getStudyCardMode(sessionMode);
      const pool = state.cards.filter((card) => card.mode === cardMode);
      const sessionLabel = getStudySessionLabel(sessionMode);

      if (!pool.length) {
        study = null;
        studyHistory = [];
        resetStudyDeck();
        saveState();
        renderAll();
        showToast(`У режимі “${sessionLabel}” більше немає карток.`);
        return;
      }

      const poolIds = pool.map((card) => card.id);
      const poolIdSet = new Set(poolIds);
      const cardsById = new Map(pool.map((card) => [card.id, card]));

      if (studyDeck.sessionMode !== sessionMode) {
        resetStudyDeck(sessionMode);
      }

      studyDeck.queueIds = studyDeck.queueIds.filter((id) => poolIdSet.has(id));

      if (!studyDeck.queueIds.length) {
        const cycleIds = buildStudyCycle(poolIds, studyDeck.lastCycleIds, excludeId);
        studyDeck.lastCycleIds = cycleIds.slice();
        studyDeck.queueIds = cycleIds.slice();
      } else {
        studyDeck.queueIds = avoidImmediateRepeat(studyDeck.queueIds, excludeId);
      }

      const cardId = studyDeck.queueIds.shift();
      const card = cardsById.get(cardId);

      if (!card) {
        pickStudyCard(excludeId, { ...options, sessionMode });
        return;
      }

      setStudyCard(card, { ...options, sessionMode });
    }

    function handleStudyAction(action, options = {}) {
  if (!study) return;

  if (action === "open-pip") {
    openStudyPictureInPicture();
    return;
  }

  const sessionMode = STUDY_SESSION_CARD_MODES[study.sessionMode] ? study.sessionMode : getSelectedStudySessionMode();
  const cardMode = getStudyCardMode(sessionMode);
  const card = state.cards.find((item) => item.id === study.cardId);

  if (!card) return;

  syncStudyAnswerFromDocument(options.sourceDocument || document);

  if (action === "flip") {
    study.flipped = !study.flipped;
    renderStudy();
    return;
  }

  if (action === "next") {
    pickStudyCard(study.cardId, {
      sessionMode,
      scroll: options.scroll !== false
    });
    return;
  }

  if (action === "previous") {
    while (studyHistory.length) {
      const previousId = studyHistory.pop();
      const previousCard = state.cards.find((item) => item.id === previousId && item.mode === cardMode);

      if (previousCard) {
        setStudyCard(previousCard, {
          rememberCurrent: false,
          sessionMode,
          scroll: options.scroll !== false
        });
        return;
      }
    }

    showToast("Попередньої картки немає.");
    return;
  }

  if (["dictionary", "learning", "reinforcement", "known"].includes(action)) {
    if (!canMoveToMode([card.id], action)) {
      showToast(getModeLimitMessage(action));
      return;
    }

    card.mode = action;
    card.updatedAt = new Date().toISOString();

    saveState();

    pickStudyCard(card.id, {
      rememberCurrent: false,
      sessionMode,
      scroll: options.scroll !== false
    });

    showToast(`Картку переміщено в “${MODE_LABELS[action]}”.`);
    return;
  }

  if (action === "edit") {
    openCardModal(card.id);
  }
}

    function insertAtCursor(targetId, char) {
      const input = document.getElementById(targetId);
      if (!input) return;

      const start = input.selectionStart ?? input.value.length;
      const end = input.selectionEnd ?? input.value.length;
      input.value = `${input.value.slice(0, start)}${char}${input.value.slice(end)}`;
      input.focus();
      input.setSelectionRange(start + char.length, start + char.length);
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }

    function bindEvents() {
      els.createCardForm.addEventListener("submit", createCard);
      els.createCardForm.addEventListener("reset", () => {
        window.setTimeout(renderCreateSideSuggestions, 0);
      });

      [els.cardFront, els.cardBack].forEach((input) => {
        input.addEventListener("input", renderCreateSideSuggestions);
        input.addEventListener("change", renderCreateSideSuggestions);
      });

      els.quickAddTag.addEventListener("click", addQuickTag);
      els.quickTagName.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          addQuickTag();
        }
      });

      els.searchInput.addEventListener("input", resetPageAndRenderCardList);
      els.modeFilter.addEventListener("change", resetPageAndRenderCardList);
      els.sortSelect.addEventListener("change", resetPageAndRenderCardList);

      els.pageSizeSelect.addEventListener("change", () => {
        const nextPageSize = Number(els.pageSizeSelect.value);
        pageSize = PAGE_SIZE_OPTIONS.includes(nextPageSize) ? nextPageSize : DEFAULT_PAGE_SIZE;
        saveStoredValue(PAGE_SIZE_KEY, pageSize);
        currentPage = 1;
        renderCardList();
      });

      els.prevPageBtn.addEventListener("click", () => {
        if (currentPage > 1) {
          currentPage -= 1;
          renderCardList();
        }
      });

      els.nextPageBtn.addEventListener("click", () => {
        const pageCount = getPageCount(getVisibleCards().length);
        if (currentPage < pageCount) {
          currentPage += 1;
          renderCardList();
        }
      });

      if (savedStudySideMode && els.studySideMode) {
        els.studySideMode.value = savedStudySideMode;
      }

      els.studySideMode.addEventListener("change", () => {
        saveStoredValue(STUDY_SIDE_MODE_KEY, els.studySideMode.value);
      });

      els.studySessionMode.addEventListener("change", () => {
        study = null;
        studyHistory = [];
        resetStudyDeck();
        renderAll();
      });

      els.studyBtn.addEventListener("click", () => {
        const sessionMode = getSelectedStudySessionMode();

        studyHistory = [];
        resetStudyDeck(sessionMode);
        pickStudyCard(null, { rememberCurrent: false, sessionMode });
      });
      els.closeStudyBtn.addEventListener("click", () => {
        study = null;
        studyHistory = [];
        resetStudyDeck();
        renderAll();
      });

      els.exportCsvBtn.addEventListener("click", exportCardsToCsv);
      els.importCsvBtn.addEventListener("click", () => els.csvFileInput.click());
      els.csvFileInput.addEventListener("change", (event) => {
        importCardsFromCsvFile(event.target.files[0]);
        event.target.value = "";
      });

      function applyBulkModeFromToolbar() {
        const mode = els.bulkModeSelect.value;
        if (!mode) {
          showToast("Оберіть режим для групової дії.");
          return;
        }

        const ids = getSelectedCardIds();
        const changed = moveCards(ids, mode);
        if (changed) {
          els.bulkModeSelect.value = "";
        }
      }
      
      els.clearSelectionBtn.addEventListener("click", clearAllSelections);
      els.bulkApplyMode.addEventListener("click", applyBulkModeFromToolbar);
      els.bulkModeSelect.addEventListener("change", () => {
        if (els.bulkModeSelect.value) applyBulkModeFromToolbar();
      });

      els.bulkAddTags.addEventListener("click", () => applyTagChange(getSelectedCardIds(), "add"));
      els.bulkReplaceTags.addEventListener("click", () => applyTagChange(getSelectedCardIds(), "replace"));
      els.bulkRemoveTags.addEventListener("click", () => applyTagChange(getSelectedCardIds(), "remove"));
      els.bulkDelete.addEventListener("click", () => deleteCards(getSelectedCardIds()));

      els.closeCardModal.addEventListener("click", closeCardModal);
      els.modalBackdrop.addEventListener("click", (event) => {
        if (event.target === els.modalBackdrop) closeCardModal();
      });
      els.editCardForm.addEventListener("submit", saveCardEdit);
      els.deleteFromModal.addEventListener("click", () => {
        const id = els.editCardId.value;
        closeCardModal();
        deleteCards([id]);
      });

      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && els.modalBackdrop.classList.contains("active")) {
          closeCardModal();
        }
      });

      document.addEventListener("click", (event) => {
        const accentButton = event.target.closest("[data-char][data-target]");
        if (accentButton) {
          insertAtCursor(accentButton.dataset.target, accentButton.dataset.char);
          return;
        }

        const sortButton = event.target.closest("[data-sort]");
        if (sortButton) {
          els.sortSelect.value = sortButton.dataset.sort;
          currentPage = 1;
          renderCardList();
          return;
        }

        const tagButton = event.target.closest("[data-tag-action]");
        if (tagButton) {
          if (tagButton.dataset.tagAction === "rename") renameTag(tagButton.dataset.tagId);
          if (tagButton.dataset.tagAction === "delete") deleteTag(tagButton.dataset.tagId);
          return;
        }

        const cardButton = event.target.closest("button[data-card-action]");
        if (cardButton) {
          const id = cardButton.dataset.cardId;
          if (cardButton.dataset.cardAction === "edit") openCardModal(id);
          if (cardButton.dataset.cardAction === "delete") deleteCards([id]);
          return;
        }

        const studyButton = event.target.closest("[data-study-action]");
        if (studyButton) {
          handleStudyAction(studyButton.dataset.studyAction);
        }
      });

      document.addEventListener("change", (event) => {
        const checkbox = event.target.closest(".card-check");
        if (checkbox) {
          if (checkbox.checked) selectedIds.add(checkbox.dataset.cardId);
          else selectedIds.delete(checkbox.dataset.cardId);
          renderCardList();
          return;
        }

        if (event.target.id === "selectAllVisible") {
          const visible = getDisplayedCards();

          if (event.target.checked) {
            visible.forEach((card) => selectedIds.add(card.id));
          } else {
            visible.forEach((card) => selectedIds.delete(card.id));
          }

          renderCardList();
          return;
        }

        const modeSelect = event.target.closest("select[data-card-action='mode']");
        if (modeSelect) {
          const id = modeSelect.dataset.cardId;
          const card = state.cards.find((item) => item.id === id);
          const previous = card ? card.mode : null;
          const ok = moveCards([id], modeSelect.value);
          if (!ok && previous) {
            modeSelect.value = previous;
          }
        }
      });

      els.studyPanel.addEventListener("input", (event) => {
        if (event.target.matches("[data-study-answer]") && study) {
          study.answer = event.target.value;
          syncStudyAnswerToPictureInPicture();
        }
      });

      window.requestAnimationFrame(renderCreateSideSuggestions);
      window.setTimeout(renderCreateSideSuggestions, 250);
    }

    async function initApp() {
      await loadStoredData();
      bindEvents();
      sortTags();
      await saveState();
      renderAll();
      bindExternalStorageSync();
    }

    initApp().catch((error) => {
      console.warn("Could not initialize app", error);
      renderAll();
      showToast("Не вдалося завантажити дані. Спробуйте перезавантажити сторінку.");
    });
